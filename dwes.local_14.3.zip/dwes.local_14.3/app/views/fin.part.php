<!-- Footer -->
<footer class="home-page">
  <div class="container text-muted text-center">
    <div class="row">
      <ul class="nav col-sm-4">
        <li class="footer-number">
          <i class="fa fa-phone sr-icons"></i> (00228)92229954
        </li>
        <li>
          <i class="fa fa-envelope sr-icons"></i> kouvenceslas93@gmail.com
        </li>
        <li>Photography Fanatic Template &copy; 2017</li>
      </ul>
      <ul class="list-inline social-buttons col-sm-4 col-sm-push-4">
        <li>
          <a href="#"><i class="fa fa-facebook sr-icons"></i></a>
        </li>
        <li>
          <a href="#"><i class="fa fa-twitter sr-icons"></i></a>
        </li>
        <li>
          <a href="#"><i class="fa fa-google-plus sr-icons"></i></a>
        </li>
      </ul>
    </div>
  </div>
</footer>

<!-- Jquery -->
<script type="text/javascript" src="/public/js/jquery.min.js"></script>
<!-- Bootstrap core Javascript -->
<script type="text/javascript" src="/public/bootstrap/js/bootstrap.min.js"></script>
<!-- Plugins -->
<script type="text/javascript" src="/public/js/jquery.easing.min.js"></script>
<script type="text/javascript" src="/public/js/jquery.magnific-popup.min.js"></script>
<script type="text/javascript" src="/public/js/scrollreveal.min.js"></script>
<script type="text/javascript" src="/public/js/script.js"></script>
</body>
</html>