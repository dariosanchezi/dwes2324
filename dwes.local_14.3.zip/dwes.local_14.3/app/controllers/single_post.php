<?php 
require_once __DIR__ . '/../views/single_post.view.php';
