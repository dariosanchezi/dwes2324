<?php
namespace dwes\app\excepciones;

use Exception;

class NotFoundException extends Exception
{

}