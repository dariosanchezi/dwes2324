<?php
namespace dwes\app\excepciones;

use Exception;

class MailException extends Exception
{

}