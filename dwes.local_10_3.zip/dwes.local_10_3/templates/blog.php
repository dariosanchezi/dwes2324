<?php
    require_once __DIR__ . '/views/blog.view.php';
