<?php

class FileException extends Exception
{

}