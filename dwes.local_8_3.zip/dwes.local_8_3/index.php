<?php
header("Location: templates/index.php");
exit();
