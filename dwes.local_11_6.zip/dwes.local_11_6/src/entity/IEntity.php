<?php

Interface IEntity {

    public function toArray(): array;

}   