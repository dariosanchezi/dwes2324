<?php

class AppException extends Exception
{

}