<?php
require_once __DIR__ . '/../src/utils/File.class.php';
require_once __DIR__ . '/../src/exceptions/FileException.class.php';
require_once __DIR__ . '/../src/exceptions/AppException.class.php';
require_once __DIR__ . '/../src/exceptions/QueryException.class.php';
require_once __DIR__ . '/../src/exceptions/CategoriaException.class.php';
require_once __DIR__ . '/../src/entity/Imagen.class.php';
require_once __DIR__ . '/../src/entity/Categoria.class.php';
require_once __DIR__ . '/../src/database/connections.class.php';
require_once __DIR__ . '/../src/repository/ImagenesRepository.php';
require_once __DIR__ . '/../src/repository/CategoriasRepository.php';

$errores=[]; $titulo=""; $descripcion=""; $mensaje="";

try {
    $config = require_once __DIR__ . '/../app/config.php';
    App::bind('config',$config);    // Guardamos la configuración en el contenedor de servicios
    
    $imagenesRepository = new ImagenesRepository();
    $imagenes = $imagenesRepository->findAll();
    $categoriasRepository = new CategoriasRepository();
    $categorias = $categoriasRepository->findAll();

    If ($_SERVER['REQUEST_METHOD'] === 'POST' ) {
        $titulo = trim(htmlspecialchars($_POST['titulo']));
        $descripcion = trim(htmlspecialchars($_POST['descripcion']));
        $categoria = trim(htmlspecialchars($_POST['categoria']));
        if ( empty($categoria))
            throw new CategoriaException;
        $tiposAceptados = ['image/jpeg', 'image/gif', 'image/png'];
        $imagen = new File('imagen', $tiposAceptados);  // El nombre 'imagen' es el que se ha puesto en el formulario de galeria.view.php
        $imagen->saveUploadFile(Imagen::RUTA_IMAGENES_SUBIDAS );

        $imagenGaleria = new Imagen($imagen->getFileName(),$descripcion, $categoria);
        $imagenesRepository->guarda($imagenGaleria);

        $mensaje = "Se ha guardado la imagen correctamente";
        $imagenes = $imagenesRepository->findAll();
    }


} catch (FileException $fileException) {
    $errores[] = $fileException->getMessage();
}
catch ( QueryException $queryException ){
    $errores[] = $fileException->getMessage();
}
catch ( AppException $appException ){
    $errores[] = $appException->getMessage();
}
catch ( CategoriaException ) {
    $errores[] = "No se ha seleccionado una categoría válida";
}

require_once __DIR__ . '/views/galeria.view.php';


