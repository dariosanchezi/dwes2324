<?php

class QueryException extends Exception
{

}