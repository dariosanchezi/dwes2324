<?php

class CategoriaException extends Exception
{

}