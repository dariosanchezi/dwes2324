<?php
namespace dwes\app\excepciones;

use Exception;

class CategoriaException extends Exception
{

}