<?php
namespace dwes\app\excepciones;

use Exception;

class AppException extends Exception
{

}