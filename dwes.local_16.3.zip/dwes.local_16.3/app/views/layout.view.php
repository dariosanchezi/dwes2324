<?php
include __DIR__ . '/inicio.part.php';
include __DIR__ . '/navegacion.part.php';
echo $mainContent;
include __DIR__ . '/fin.part.php';
