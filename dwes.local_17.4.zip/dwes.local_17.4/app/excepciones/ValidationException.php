<?php
namespace dwes\app\excepciones;

use Exception;

class ValidationException extends Exception
{

}