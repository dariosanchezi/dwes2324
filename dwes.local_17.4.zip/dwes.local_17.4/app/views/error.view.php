<div id="error">
    <div class="container">
        <h1><?= $httpHeaderMessage ?></h1>

        <p><?= $errorMessage ?></p>
    </div>
</div>
